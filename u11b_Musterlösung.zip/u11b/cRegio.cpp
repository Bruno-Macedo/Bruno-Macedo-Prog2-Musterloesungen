#include "cRegio.h"

cRegio::cRegio(int reisende_in, int verspaetung_in) : cZugFahrt(reisende_in, verspaetung_in) {};

int cRegio::spaetMinuten() {
	return (getReisende() * getVerspaetung() * 4) + ((0.7 * getReisende()) * getVerspaetung() * 4);
}	//Nach den ersten 4 Haltestellen, fahren nur noch 70% der Gaeste mit
