#pragma once
#include "cZugFahrt.h"
class cFernZug :
    public cZugFahrt
{
public:
    cFernZug(int = 400, int = 5);
    virtual int spaetMinuten();
};

