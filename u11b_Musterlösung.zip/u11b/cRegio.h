#pragma once
#include "cZugFahrt.h"

class cRegio :             
    public cZugFahrt
{
public:
    cRegio(int = 400, int = 5);
    virtual int spaetMinuten();
};

