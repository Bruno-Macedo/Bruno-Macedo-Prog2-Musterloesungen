#include "cZugFahrt.h"
#include "cRegio.h"
#include "cFernZug.h"
#include "cNachtZug.h"
#include "cRegioExpress.h"

int main() {

	cZugFahrt* zuege [] = { new cRegio, new cFernZug(800,15), new cRegioExpress(600,0),
					new cNachtZug(250, 140), new cRegioExpress(120,42), new cFernZug(300,55) };

	int gesamtVerspaetung = 0;

	for (cZugFahrt * zug : zuege) {
		gesamtVerspaetung += zug->spaetMinuten();
	}	//For-Each Loop

	cout << "Die Gesamtzahl der Verspaetungsminuten lautet: " << gesamtVerspaetung << endl;

	for (cZugFahrt * zugZerstoere : zuege) {
		delete zugZerstoere;
	}	//Zerstoerung der Objekte

	return 0;
}