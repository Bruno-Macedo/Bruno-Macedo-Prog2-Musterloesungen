#include "cNachtZug.h"

cNachtZug::cNachtZug(int reisende_in, int verspaetung_in) : cZugFahrt(reisende_in, verspaetung_in) {};

int cNachtZug::spaetMinuten() {

	string wochentag;

	while (1) {
		cout << "NachtZug: Geben Sie bitte den Wochentag ein: ";
		cin >> wochentag;
		cout << endl;

		if (wochentag == "Montag" || wochentag == "montag") {
			return getReisende() * getVerspaetung() * 0.2;
		}
		else if (wochentag == "Dienstag" || wochentag == "dienstag") {
			return getReisende() * getVerspaetung() * 0.2;
		}
		else if (wochentag == "Mittwoch" || wochentag == "mittwoch") {
			return getReisende() * getVerspaetung() * 0.2;
		}
		else if (wochentag == "Donnerstag" || wochentag == "donnerstag") {
			return getReisende() * getVerspaetung() * 0.2;
		}
		else if (wochentag == "Freitag" || wochentag == "freitag") {
			return getReisende() * getVerspaetung() * 0.4;
		}
		else if (wochentag == "Samstag" || wochentag == "samstag") {
			return getReisende() * getVerspaetung() * 0.1;
		}
		else if (wochentag == "Sonntag" || wochentag == "sonntag") {
			return getReisende() * getVerspaetung() * 0.4;
		}
		else {
			cout << "Sie haben einen ungueltigen Wochentag eingegeben. Ueberpruefen Sie Ihre Rechtschreibung und versuchen Sie es nochmal." << endl;
		}
	}	//Fuer den Fall, dass der Wochentag falsch geschrieben wurde, wird die loop so oft wiederholt, bis es einen return Wert gibt
}