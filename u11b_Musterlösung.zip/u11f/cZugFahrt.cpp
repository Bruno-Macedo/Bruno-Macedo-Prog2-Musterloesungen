#include "cZugFahrt.h"

cZugFahrt::cZugFahrt(int reisende_in, int verspaetung_in) {
	reisende = reisende_in;
	verspaetung = verspaetung_in;
}

int cZugFahrt::getReisende() {
	return reisende;
}

int cZugFahrt::getVerspaetung() {
	return verspaetung;
}
