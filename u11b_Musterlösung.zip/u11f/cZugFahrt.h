#pragma once
#include <iostream>	//Fuer die Klassen FernZug und NachtZug
using namespace std;

class cZugFahrt
{
private:
	int reisende;		//Anzahl der Reisenden
	int verspaetung;	//Anzahl der Minuten der Verspaetung des Zuges
public:
	cZugFahrt(int = 400, int = 5);
	virtual int spaetMinuten() = 0;
	int getReisende();
	int getVerspaetung();
};

