#pragma once
#include "cRegio.h"
class cRegioExpress :
    public cRegio
{
public:
    cRegioExpress(int = 400, int = 5);
    virtual int spaetMinuten();
};

