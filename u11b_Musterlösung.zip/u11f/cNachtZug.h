#pragma once
#include "cZugFahrt.h"
class cNachtZug :
    public cZugFahrt
{
public:
    cNachtZug(int = 400, int = 5);
    virtual int spaetMinuten();
};

