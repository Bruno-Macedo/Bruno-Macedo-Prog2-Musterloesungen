#include "cRegioExpress.h"

cRegioExpress::cRegioExpress(int reisende_in, int verspaetung_in) : cRegio(reisende_in, verspaetung_in) {};

int cRegioExpress::spaetMinuten() {
	int umsteiger;

	cout << "RegioExpress: Geben Sie den Anteil der Umsteiger ein: ";
	cin >> umsteiger;
	cout << endl;

	int nicht_umsteiger = getReisende() - umsteiger;

	return (nicht_umsteiger * getVerspaetung() * 3) + (umsteiger * (60 - getVerspaetung()) * 3);
}	//Bei den Umsteigern wird eine Wartezeit von 60min abzueglich der Verspaetung beruecksichtigt
