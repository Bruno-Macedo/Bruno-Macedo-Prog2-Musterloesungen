#include "cPunkt.h"

void cPunkt::korKoordinaten()
{
	// Koordinatenwerte muessen im Bereich von -10 bis 10 liegen. 
	// Bei Ueberschreitung der zulaessigen Grenzen Anpassung an den Grenzwert von -10 bzw. 10

	//Fuer x-Koordinaten
	if (x > 10.0) x = 10.0;
	if (x < -10.0) x = -10.0;

	//Fuer y-Koordinaten
	if (y > 10.0) y = 10.0;
	if (y < -10.0) y = -10.0;
}

cPunkt::cPunkt(double x_in, double y_in)
{
	x = x_in;
	y = y_in;

	korKoordinaten();  // Korrektur der Koordinatenwerte, falls der Bereich von - 10 bis 10 ��berschritten wird
}

void cPunkt::ausgabe()
{
	// Ausgabe der x- und y-Koordinaten eines Punktes auf der Konsole

	cout << "x: " << x << " y: " << y << endl;
}

double cPunkt::get_x()
{
	return x;
}

double cPunkt::get_y()
{
	return y;
}
