#pragma once
#include "cPunkt.h"
#include<iostream>
using namespace std;

class cDreieck
{
private:
	cPunkt a, b, c; // Eckpunkte des Dreiecks

	double umfangD();
	double flaecheD();
	double streckenlaenge(cPunkt x_1, cPunkt x_2);

public:
	cDreieck(cPunkt a_in = { 0.0, 1.0 }, cPunkt b_in = { 1.0, 0.0 }, cPunkt c_in = { 0.0, 0.0 });
	void ausgabe();
};

