/*
Name: Andrej Alpatov
Datum: 19.04.2022
Aufgabe: u03d
Programm: Aggregation, Erstellen eines Arrays von Klassenobjekten mit Initialisierung.
*/

#include"cDreieck.h"

int main() {

	// Erstellen und Initialisieren eines Arrays aus drei Objekten der Klasse cDreieck
	cDreieck array_von_dreiecken[] = { {cPunkt(23.9, 3.13), cPunkt(5.24, -16.8), cPunkt(-6.72, 8.42)},
										{cPunkt(0.5, 1.0), cPunkt(1.5, 0.0), cPunkt(0.5, 0.0)},
										{cPunkt(), cPunkt(), cPunkt()}
	};

	// Ausgabe der Werte von Array-Elementen auf der Konsole
	for (cDreieck element : array_von_dreiecken) {
		cout << "*************************************" << endl;
		element.ausgabe();
	}

	return 0;
}