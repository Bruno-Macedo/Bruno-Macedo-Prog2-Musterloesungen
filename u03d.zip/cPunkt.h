#pragma once
#include<iostream>
using std::cout;
using std::endl;

class cPunkt
	// Klasse fuer die Punkte auf der Koordinatenebene
{
private:
	double x, y; // Koordinaten auf der x- und y-Achse

	void korKoordinaten();
public:
	cPunkt(double x_in = 0.0, double y_in = 0.0);
	void ausgabe();
	double get_x();
	double get_y();
};

