#include "cDreieck.h"

double cDreieck::umfangD()
{
	// Gibt den Umfang eines Dreiecks zurueck

	return streckenlaenge(a,b) + streckenlaenge(b, c) + streckenlaenge(c,a);
}

double cDreieck::flaecheD()
{
	// Gibt die Flaeche eines Dreiecks zurueck

	double umfangshaelfte = umfangD() / 2.0;  // Die Haelfte der Flaeche eines Dreiecks

	return sqrt(umfangshaelfte * (umfangshaelfte - streckenlaenge(a, b)) * (umfangshaelfte - streckenlaenge(b, c)) *
		(umfangshaelfte - streckenlaenge(c, a)));
}

double cDreieck::streckenlaenge(cPunkt x_1, cPunkt x_2)
{
	// Gibt den Abstand zwischen zwei Punkten zurueck

	return sqrt(pow(x_2.get_x() - x_1.get_x(), 2) + pow(x_2.get_y() - x_1.get_y(), 2));
}



cDreieck::cDreieck(cPunkt a_in, cPunkt b_in, cPunkt c_in): a(a_in), b(b_in), c(c_in)
{
	// Universeller Konstruktor
}

void cDreieck::ausgabe()
{
	// Geben Sie die Koordinaten der Eckpunkte des Dreiecks, 
	// seine Flaeche und seinen Umfang an die Konsole aus

	a.ausgabe();
	b.ausgabe();
	c.ausgabe();
	cout << "Flaeche: " << flaecheD() << " Umfang: " << umfangD() << endl;
}
