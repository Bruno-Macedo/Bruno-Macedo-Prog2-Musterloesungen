#pragma once
#include <iostream>
using namespace std;

#define NIL (cSchachfeld*) 0		//Nullzeiger

class cSchachfeld
{
private:
	char x;
	int y;
	cSchachfeld* prev;

	bool testZug(char new_x, int new_y);	//Hilfsmethode Zug Gueltigkeit --> Mathematisch?
	bool testBlock(char new_x, int new_y);	//Hilfsmethode Zug Gueltigkeit --> Besetzt?

	friend bool vergleichPos(const cSchachfeld& s1, const cSchachfeld& s2);	//Hilfsfunktion Vergleich Aktuelles Feld == Zielfeld?
public:
	cSchachfeld(char, int, cSchachfeld* = NIL);		//Konstruktor mit Standardwert fuer prev auf Nullzeiger
	~cSchachfeld();									//Destruktor wichtig, da verkettete Liste

	cSchachfeld* springerZug();		//Methode zum Aufbauen der verketteten Liste
	void printSpiel();				//Ausgabe fuer die verkettete Liste
};

