/* Musterloesung u06a
 * 20.05.2022 
 * Dani */

#include "cSchachfeld.h"

int main() {

	cSchachfeld* p_act = new cSchachfeld('E', 6);	//Startfeld
	cSchachfeld* p_ziel = new cSchachfeld('C', 1);	//Zielfeld

	while (vergleichPos(*p_act, *p_ziel) != 1) {	//Aktuelles Feld wird mit Zielfeld verglichen
		p_act = p_act->springerZug();				
	}

	cout << "Das Ziel wurde erreicht!" << endl;		//Schleife wird erst verlassen, wenn aktuelles Feld = Zielfeld
	cout << "Dies waren Ihre Zuege: " << endl;		//Sinnvoll waere hier auch eine Fehlerbehandlung, fuer den Fall, 
													//dass die Schleife verlassen wird ohne beim Zielfeld zu sein
	p_act->printSpiel();		//Ausgabe

	cout << "Spiel beenden..." << endl;

	delete p_act;		//Wer new verwendet, muss auch delete verwenden!
	delete p_ziel;

	return 0;
}