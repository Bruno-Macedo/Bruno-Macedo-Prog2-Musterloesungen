#include "cJukebox.h"
#include <iostream>
using namespace std;

int cJukebox::operator[](int index)
{
	if (index >= 1 && index <= 100) {
		cout << "Lang lebe Twist, Boogie, RocknRoll\n";
		return index * 2;
	}
	else if (index >= 101 && index <= 200) {
		cout << "Traeumerisch schauen und gelegentlich seufzen\n";
		return index * 13 - 100;
	}
	else if (index == 222) {
		cout << "It's time to say Goodbye\n";
		return -1;
	}
	else if ((index >= 201 && index <= 221) || (index >= 223 && index <= 300)) {
		cout << "Raven bis zum Morgengrauen\n";
		return index * (int)777.77 % 11;
	}
	else {
		cout << "Falsche Eingabe";

		exit(1);
	}
}
