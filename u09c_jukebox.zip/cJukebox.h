#pragma once

class cJukebox
{
public:
	int operator [](int index);

};

