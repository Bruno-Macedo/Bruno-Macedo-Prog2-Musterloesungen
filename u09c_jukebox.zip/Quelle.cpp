//Task: Ueberladen des Subskriptoperators mit Simulation einer Jukebox)
//u08d 
//Date: 22.11.2019
//Author: Andrej Alpatov
#include<iostream>
#include"cJukebox.h"
using namespace std;

int main() {

	int musiktitel = 0; // help variable for 
	int	ausgabe = 0;
	const int EXIT = 222;
	cJukebox jukebox;


	while (musiktitel != EXIT)
	{
		cout << "Geben Sie eine Titelsnummer zwischen 1 und 300 (222 fuer EXIT) ein" << endl;
		cin >> musiktitel;

		// Valid Range from 1 to 300
		if (musiktitel < 1 || musiktitel > 300) {
			cout << "Falsche Eingabe\n";
			continue;
		}
		// Usage of subscript operator on the cJukebox object 
		ausgabe = jukebox[musiktitel];
		cout << "Subskriptionsergebnis: " << ausgabe << endl <<
			"**************************************" << endl;
	}

	return 0;
}