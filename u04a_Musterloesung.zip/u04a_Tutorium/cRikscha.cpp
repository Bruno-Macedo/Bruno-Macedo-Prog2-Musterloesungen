#include "cRikscha.h"

cRikscha::cRikscha(int rad_in, double luft_in, double ertrag_in, int gast_in) : cNutzrad(rad_in, luft_in, ertrag_in)
{
	if (gast_in < 0) {			//Begrenzugen abzuleiten aus den beiden anderen Methoden
		fahrgastzahl = 0;
	}
	else if (gast_in < 7) {
		fahrgastzahl = 7;
	}
	else {
		fahrgastzahl = gast_in;
	}
}

int cRikscha::einsteigen(int rein)
{
	if (rein >= 0) {
		if (fahrgastzahl + rein > 7) {
			cout << "Die Rikscha ist schon zu voll" << endl;
			//fahrgastzahl = 7;		//Annahme man fuellt mit Einzelpersonen bis zum Maximum und es gibt keine Gruppe die zusammenbleiben will
		}
		else {
			fahrgastzahl += rein;
		}
	}
	else {
		cout << "Kein negatives Einsteigen m�glich. Versuchen Sie es mit Aussteigen" << endl; //Fahrgastanzahl wird nicht veraendert
	}
	return fahrgastzahl;
}

int cRikscha::aussteigen(int raus)
{
	if (raus <= 0) {
		if (fahrgastzahl - raus < 0) {
			cout << "Es steigen mehr Leute aus, als mitgefahren sind. Gruselig" << endl;
			fahrgastzahl = 0;
		}
		else {
			fahrgastzahl -= raus;
		}
	}
	else {
		cout << "Du kannst nicht positiv aussteigen. Versuch es mit einsteigen" << endl; //Fahrgastanzahl wird nicht veraendert
	}
	return fahrgastzahl;
}
