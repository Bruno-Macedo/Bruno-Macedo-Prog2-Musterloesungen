#include "cEinrad.h"

cEinrad::cEinrad(int rad_in, double luft_in, double spass_in) : cFreizeitrad(rad_in, luft_in, spass_in)
{
}

double cEinrad::geniessen(double genuss) 
{
	if (genuss >= 0) {
		setSpass(getSpass() + 20 * genuss);		//Der Genuss erhoeht sich um Faktor 20 bei Positiver Zahl
	}
	else {
		if ((getSpass() - 5 * genuss) < 0.0) { //Abfangen des Falles, dass Spass unter 0 faellt
			setSpass(0.0);
		}
		else {
			setSpass(getSpass() - 5 * genuss); //Der Genuss verringert sich um Faktor 5 bei Negativer Zahl
		}
	}
	return getSpass();
}
