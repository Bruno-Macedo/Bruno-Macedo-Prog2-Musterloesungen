/* Musterloesung zu u04a - Vererbung und Mehrfachvererbung 
 * 02.05.22
 * Dani
 */

#include "cLastdreirad.h"
#include "cRikscha.h"
#include "cMountainbike.h"
#include "cEinrad.h"
#include "cRennrad.h"

int main() {

	cLastdreirad hauruck;
	cRikscha einergehtnochrein;
	cMountainbike downhillstar;
	cEinrad obenbleiben;
	cRennrad nodope;

	// Mit den Objekten spielen:
	cout << "Radzahl des Lastdreirads: " << hauruck.getRadzahl() << endl;
	cout << "Radzahl der Rikscha: " << einergehtnochrein.getRadzahl() << endl;
	cout << "Radzahl des Mountainbikes: " << downhillstar.getRadzahl() << endl;
	cout << "Radzahl des Einrads: " << obenbleiben.getRadzahl() << endl;
	cout << "Mountainbike nach 500 meter downhill, spass = "
		<< downhillstar.downhill(500) << endl;
	cout << "Mountainbike bekommt einen Steinschlag" << endl;
	downhillstar.steinschlag();
	cout << "Mountainbike nach Steinschlag, spass = " << downhillstar.downhill(0)
		<< endl;
	cout << "Mountainbike bekommt einen Steinschlag" << endl;
	downhillstar.steinschlag();
	cout << "Mountainbike nach Steinschlag, spass = " << downhillstar.downhill(0)
		<< endl;
	cout << "Radzahl des Rennrads: " << nodope.cFahrrad::getRadzahl() << endl;
	nodope.aufpumpen(1.3);
	cout << "Rennrad nach Aufpumpen, luftdruck = " << nodope.cFahrrad::getLuftdruck() << endl;
	cout << "Ende" << endl;

	return 0;
}