#include "cNutzrad.h"

cNutzrad::cNutzrad(int rad_in, double luft_in, double ertrag_in) : cFahrrad(rad_in, luft_in)
{
	ertrag = ertrag_in;	//Hier habe ich keine Begrenzung implementiert. Rein theoretisch kann man ja Schulden ansammeln
}

double cNutzrad::kassieren(double einkommen)
{
	ertrag += einkommen;
	return ertrag;
}

double cNutzrad::wartungmachen(double kosten)
{
	ertrag -= kosten; //Verluste jederzeit moeglich, also auch hier keine Begrenzung
	return ertrag;
}
