#include "cFreizeitrad.h"

cFreizeitrad::cFreizeitrad(int rad_in, double luft_in, double spass_in) : cFahrrad (rad_in, luft_in)
{
	if (spass_in >= 0) {
		spass = spass_in;
	}
	else {
		spass = 0.0;
	}
}

void cFreizeitrad::abschlie�en(bool disziplin)
{
	if (disziplin) {
		spass += 20.0;
	}
	else {
		spass = 0.0;
	}
}

double cFreizeitrad::geniessen(double genuss)
{
	spass += genuss;
	return spass;
}

double cFreizeitrad::getSpass()
{
	return spass;
}

void cFreizeitrad::setSpass(double newSpass) 
{
	spass = newSpass; //Hier koennte man erneut sichern, dass Spass nicht unter 0 faellt, ich frage dies jedoch erst bei Gebrauch der Funktion ab
}
