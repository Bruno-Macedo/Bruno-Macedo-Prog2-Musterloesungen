#pragma once
#include "cNutzrad.h"
#include "cFreizeitrad.h"

class cRennrad :
    public cNutzrad, cFreizeitrad
{
private:
    int gang;
public:
    cRennrad(int = 2, double = 5.4, double = 0.0, double = 75.0, int = 18);
    int schalten(int);
    double aufpumpen(double);
};

