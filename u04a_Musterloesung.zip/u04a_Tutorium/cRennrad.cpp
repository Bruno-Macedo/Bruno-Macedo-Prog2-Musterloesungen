#include "cRennrad.h"

cRennrad::cRennrad(int rad_in, double luft_in, double ertrag_in, double spass_in, int gang_in) : cNutzrad(rad_in, luft_in, ertrag_in), cFreizeitrad(rad_in, luft_in, spass_in)
{
	if (gang_in > 0) {	//Begrenzung auf mindestens 1 Gang
		gang = gang_in;
	}
	else {
		gang = 1;
	}
}

int cRennrad::schalten(int gangwechsel)
{
	if (gangwechsel >= 0) { //Bei positivem Wert erhoeht sich Gang um 1
		gang += 1;
	}
	else {
		if (gang - 1 > 0) { //Begrenzung bei 1
			gang -= 1;
		}
		else {			//Ansonsten wird auf den 1. Gang geschaltet
			gang = 1;	
		}
	}
	return gang;
}

double cRennrad::aufpumpen(double druckplus)
{
	if (druckplus >= 0) { //Schauen ob druckplus positiv ist
		if (cFahrrad::getLuftdruck() + druckplus > 6) {
			cFahrrad::setLuftdruck(6.0); //Begrenzung umsetzen
		}
		else {
			cFahrrad::setLuftdruck(cFahrrad::getLuftdruck() + druckplus); //Bei der Mehrfachvererbung muss ich die genaue Klasse angeben aus welcher ich Methoden aufrufen will
		}
	}
	else {
		cout << "Es kann nicht negativ aufgepumpt werden" << endl; //Unveraenderter Luftdruck wird zurueckgegeben
	}
	return cFahrrad::getLuftdruck();
}
