#pragma once
#include "cNutzrad.h"
class cRikscha :
    public cNutzrad
{
private:
    int fahrgastzahl;
public:
    cRikscha(int = 4, double = 2.7, double = 620.0, int = 1);
    int einsteigen(int);
    int aussteigen(int);
};

