#pragma once
#include "cFahrrad.h"
class cFreizeitrad :
    public cFahrrad
{
private:
    double spass;
public:
    cFreizeitrad(int, double, double); //Das Freizeitrad muss auch sein inneres Fahrrad befuellen
    void abschlie�en(bool);
    double geniessen(double);

    //Wichtig f�r cMountainbike
    double getSpass();
    void setSpass(double);
};

