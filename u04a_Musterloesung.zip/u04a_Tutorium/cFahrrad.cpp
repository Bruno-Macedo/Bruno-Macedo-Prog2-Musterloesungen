#include "cFahrrad.h"

cFahrrad::cFahrrad(int rad_in, double luft_in)
{
	radzahl = rad_in;

	if (luft_in >= 3.5) {		//Begrenzung auf 3.5 bar wird �berpr�ft
		luftdruck = luft_in;
	}
	else {
		luftdruck = 3.5;	//In einem Konstruktor muessen immer alle Werte befuellt werden und alle Kontrollstrukturen muessen dafuer sorgen
	}
}

int cFahrrad::getRadzahl()
{
	return radzahl;
}

double cFahrrad::getLuftdruck()
{
	return luftdruck;
}

void cFahrrad::setLuftdruck(double newLuft)
{
	luftdruck = newLuft;
}

double cFahrrad::aufpumpen(double druckplus)
{
	if (druckplus >= 0) {
		if (luftdruck + druckplus > 3.5) {
			cout << "Der Luftdruck darf 3.5 bar nicht �berschreiten" << endl;
			luftdruck = 3.5;
		}
		else {
			luftdruck += druckplus;	
		}
	}
	else {
		cout << "Du kannst nicht negative Luft aufpumpen" << endl;
	}
	return luftdruck;
}
