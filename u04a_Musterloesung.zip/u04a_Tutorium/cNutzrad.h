#pragma once
#include "cFahrrad.h"
class cNutzrad :
    public cFahrrad
{
private:
    double ertrag;
public:
    cNutzrad(int, double, double);
    double kassieren(double);
    double wartungmachen(double);
};

