#include "cMountainbike.h"

cMountainbike::cMountainbike(int rad_in, double luft_in, double spass_in) : cFreizeitrad(rad_in, luft_in, spass_in)
{
}

double cMountainbike::downhill(int hoehendifferenz)
{
	setSpass(getSpass() + (10.0 * hoehendifferenz)); //Hier muessen wir setSpass und getSpass verwenden, da wir nicht auf private Attribute der Elternklasse zugreifen koennen
	return getSpass();
}

void cMountainbike::steinschlag()
{
	if (getSpass() - 2000 < 0) {	//Spass nicht unter 0 abfangen
		cout << "So wenig Spass kann keiner haben" << endl;
		setSpass(0.0);
	}
	else {
		setSpass(getSpass() - 2000);
	}

	if (getSpass() == 0) {
		schimpfen();
	}
}

void cMountainbike::schimpfen()
{
	cout << "Schon wieder ein Stein, macht keinen Spass mehr" << endl;
}
