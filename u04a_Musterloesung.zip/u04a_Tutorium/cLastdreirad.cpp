#include "cLastdreirad.h"

cLastdreirad::cLastdreirad(int rad_in, double luft_in, double ertrag_in, double nutz_in) : cNutzrad(rad_in, luft_in, ertrag_in)
{
	if (nutz_in < 0.0) { //Nutzlast sollte nicht negativ sein
		nutzlast = 0.0;
	}
	else {
		nutzlast = nutz_in;	//Erneut brauchen wir eine Loesung fuer den Fall, dass der uebergebene Parameter nicht in die Rahmenbedingungen passt
	}						//Wir koennen "nutzlast" nicht unbefuellt lassen. Alle Attribute muessen initialisiert werden
}

double cLastdreirad::zuladen(double lastplus)
{
	nutzlast += lastplus;
	return nutzlast;
}

double cLastdreirad::abladen(double lastminus)
{
	if (nutzlast - lastminus < 0.0) { //Nutzlast sollte wieder nicht negativ sein
		nutzlast = 0.0;
	}
	else {
		nutzlast -= lastminus;
	}
	return nutzlast;
}
