#pragma once
#include <iostream>
using namespace std;

class cFahrrad
{
private:
	int radzahl;
	double luftdruck;

public:
	cFahrrad(int, double); //Reihenfolge ist gerade bei der Vererbung sehr wichtig
	int getRadzahl();
	double getLuftdruck();
	void setLuftdruck(double); //Fuer Rennrad
	double aufpumpen(double);
};

