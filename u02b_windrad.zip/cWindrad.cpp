#include "cWindrad.h"
#include <iomanip>

// Korrektur der Hoehe von Windanlagen 
void cWindrad::korrHoehe()
{
	if (longitude < 6.7 && latitude > 53.2) {  // im Offshore, max 200 Meter
		if (hoehe > 200) hoehe = 200;
	}
	else {  // nicht im Offshore, max 120 Meter
		if (hoehe > 120) hoehe = 120;
	}

	// Falls negative Werte eingegeben wurden
	if (hoehe < 0) hoehe *= -1;
}

// Universeller Konstruktor
cWindrad::cWindrad(string typ_in, double hoehe_in, double leistung_in, double longitude_in, 
	double latitude_in)
{
	typ = typ_in;
	hoehe = hoehe_in;
	leistung = leistung_in;
	longitude = longitude_in;
	latitude = latitude_in;

	korrHoehe();  // Korrektur der Hoehe von Windanlagen
}

// Ermoeglicht dem Benutzer, die Werte von Klassenobjekten zu aendern
void cWindrad::eingabe()
{
	cout << "Geben Sie den Typ ein.\n\"-\" Falls Sie die Werte nicht mehr ausfuellen moechten" << endl;
	cin >> typ;

	// Abbruch, falls User nicht mehr Werte eingeben will. Typ == "-" ist Abbruchbedingung
	if (typ == "-") {
		return;
	}

	cout << "Geben Sie die Hoehe ein" << endl;
	cin >> hoehe;
	cout << "Geben Sie die Leistung ein" << endl;
	cin >> leistung;
	cout << "Geben Sie Longitude ein" << endl;
	cin >> longitude;
	cout << "Geben Sie Latitude ein" << endl;
	cin >> latitude;

	korrHoehe(); //Hoehekorrektur der Windanlagen
}

// Ausgabe der Werte von Attributen des Objekts
void cWindrad::ausgabe()
{
	cout << "Typ: " << typ << " Hoehe: " << hoehe << " Leistung: " << leistung
		<< " Longitude: " << longitude << " Latitude " << latitude << endl;
}

// Ausgabe der Werte von Attributen des Objekts fuer tabellarische Darstellung
void cWindrad::ausgabe_tabelle()
{
	cout << setw(10) << typ << setw(10) << hoehe << setw(12) << leistung << setw(15) << longitude << setw(15) 
		<< latitude << endl;
}

// Gibt den Wert des Typs. Verwendet fuer Eingabeabbruch
string cWindrad::get_typ()
{
	return typ;
}
