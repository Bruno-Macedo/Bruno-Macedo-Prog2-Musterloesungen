/*
* Name: Alpatov Andrej
* Datum: 12.04.2022
* Aufgabe: u02b
* Programm: Klassendefinition, Attribute und Methoden
*/

#include "cWindrad.h"   // Um Objekte der Klasse cWindrad instanziieren zu koennen
#include <iomanip>
#define ARRAY_SIZE 1000 // Definition der Arraygroesse fuer Verwendung in main()

int main() {

	// Definition der 3 Objekte vom Typ Windrad
	cWindrad wr1("Windstrom23", 131.8, 320.0, 48.3, 8.72),
		wr2("Watt4Watt78", 192.7, 730.0, 5.8, 56.76),
		wr3;

	// Ausgabe der Werte von 3 Objekten
	wr1.ausgabe();
	wr2.ausgabe();
	wr3.ausgabe();

	cWindrad windrad_array[ARRAY_SIZE];  // Definition eines Arrays vom Typ cWindrad
	int counter = 0;	// Um die Anzahl der Aufrufe der eingabe() zu zaehlen, 
						//damit nach Abschluss ausgabe() genauso oft aufgerufen wird

	// Eingeben von Daten fuer Objekte aus windrad_array
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		windrad_array[i].eingabe();
		counter++;

		if (windrad_array[i].get_typ() == "-")	break;  // Abbruchbedingung ("-")
		windrad_array[i].ausgabe();  // Ausgabe fuer Kontrolle
	}

	// Kopfzeile fuer die tabellarische Ausgabe
	cout << setw(10) << "Typ" << setw(10) << "Hoehe" << setw(12) << " Leistung" << setw(15) << " Longitude" 
		<< setw(15) << " Latitude" << endl;
	cout << "**************************************************************************" << endl;

	// Ausgabe der, von Benutzer ausgefuelten, Elemente des Arrays
	for (int i = 0; i < counter - 1; i++)
	{
		windrad_array[i].ausgabe_tabelle();
	}
	cout << "**************************************************************************" << endl;

	return 0;
}