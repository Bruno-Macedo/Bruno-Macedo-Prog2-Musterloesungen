#pragma once
#include <string>
#include <iostream>
using namespace std;

class cWindrad
{
private:
	string typ;
	double hoehe, leistung, longitude, latitude;

	void korrHoehe();

public:
	cWindrad(string typ = "--", double hoehe = 130.0, double leistung = 0.0, double longitude = 0.0,
		double latitude = 0.0);
	void eingabe();
	void ausgabe();
	void ausgabe_tabelle();
	string get_typ();
};

