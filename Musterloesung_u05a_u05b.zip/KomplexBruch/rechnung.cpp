/* Musterloesung zu u05a Bruch und u05b KompRat*/
/* 13.05.2022 */
/* Dani */

#include "cBruch.h"
#include "cKompRat.h"

#include <iostream>
using namespace std;

cBruch add(cBruch a, cBruch b) {
	cBruch c;	

	c.zaehler = ((a.zaehler * b.nenner) + (b.zaehler * a.nenner));
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c;
}

cBruch subt(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = ((a.zaehler * b.nenner) - (b.zaehler * a.nenner));
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c;
}

cBruch mul(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = a.zaehler * b.zaehler;
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c;
}

cBruch div(cBruch a, cBruch b) {	
	cBruch c;

	c.zaehler = a.zaehler * b.nenner;
	c.nenner = a.nenner * b.zaehler;

	c.kuerzen();
	return c;
}

int vergleich(cBruch a, cBruch b) {
	if (a.getGleitkomma() < b.getGleitkomma()) {
		return -1;
	}
	else if (a.getGleitkomma() == b.getGleitkomma()) {
		return 0;
	}
	else { //Keine erneute if-Abfrage notwendig, Kleiner oder gleich bereits ausgeschlossen
		return 1; 
	}
}

cKompRat add(cKompRat a, cKompRat b) {
	cKompRat c;

	c.real = add(a.real, b.real); //Greift auf die add() Funktion von cBruch zu
	c.imag = add(a.imag, b.imag);

	return c;
}

cKompRat subt(cKompRat a, cKompRat b) {
	cKompRat c;

	c.real = subt(a.real, b.real); //Auch hier Verwendung von cBruchs Friend Subtraktion
	c.imag = subt(a.imag, b.imag);

	return c;
}

int kompRatVergleich(cKompRat a, cKompRat b) {
	double betrag_a = sqrt(pow(a.real.getGleitkomma(), 2) + pow(a.imag.getGleitkomma(), 2));	//Betrag Z = sqrt(real^2 + imaginaer^2)
	double betrag_b = sqrt(pow(b.real.getGleitkomma(), 2) + pow(b.imag.getGleitkomma(), 2));	//Pythagoras, wir wollen die Laenge von der Hypotenuse

	if (betrag_a > betrag_b) {
		return 1;
	}
	else if (betrag_a == betrag_b) {
		return 0;
	}
	else {
		return -1;
	}
}

int main() {

	//u05a
	cBruch helpme;	//Hilfsvariable
	cBruch cBArr[8] = { cBruch(3,4),
						cBruch(2,3),
						cBruch(4,-24),
						cBruch(-7,9),
						cBruch(-5,-3),
						cBruch(-14,22),
						cBruch(25,12),
						cBruch(7, 5) };

	for (int i = 0; i <= 7; i++) {
		cBArr[i].ausgabe();
	}

	helpme = add(cBArr[0], cBArr[1]);
	cout << "Ergebnis Addition: "; helpme.ausgabe();

	helpme = subt(cBArr[2], cBArr[3]);
	cout << "Ergebnis Subtraktion: "; helpme.ausgabe();

	helpme = mul(cBArr[4], cBArr[5]);
	cout << "Ergebnis Multiplikation: "; helpme.ausgabe();

	helpme = div(cBArr[6], cBArr[7]);
	cout << "Ergebnis Division: "; helpme.ausgabe();

	cout << "Vergleich Bruch 1 und Bruch 2: " << vergleich(cBArr[0], cBArr[1]) << endl;
	cout << "Vergleich Bruch 3 und Bruch 4: " << vergleich(cBArr[2], cBArr[3]) << endl;
	cout << "Vergleich Bruch 5 und Bruch 6: " << vergleich(cBArr[4], cBArr[5]) << endl;
	cout << "Vergleich Bruch 7 und Bruch 8: " << vergleich(cBArr[6], cBArr[7]) << endl;

	//u05b
	/*cKompRat helpme; //Wer beide Main() Funktionen gleichzeitig laufen lassen will muss eine helpme umbenennen

	cKompRat kompRatArr[4] = {	cKompRat(cBruch(21,56), cBruch(3,7)),
								cKompRat(cBruch(24, -6), cBruch(5,7)),
								cKompRat(cBruch(-8,13), cBruch(7, -11))};

	cout << "Ausgabe des Arrays:" << endl;

	for (int i = 0; i <= 3; i++) {
		kompRatArr[i].ausgabe();
	}

	helpme = add(kompRatArr[0], kompRatArr[1]);
	cout << "\nErgebnis Addition: " << endl; helpme.ausgabe();

	helpme = subt(kompRatArr[2], kompRatArr[3]);
	cout << "\nErgebnis Subtraktion 1: " << endl; helpme.ausgabe();

	helpme = subt(kompRatArr[2], kompRatArr[1]);
	cout << "\nErgebnis Subtraktion 2: " << endl; helpme.ausgabe();*/

	return 0;
}