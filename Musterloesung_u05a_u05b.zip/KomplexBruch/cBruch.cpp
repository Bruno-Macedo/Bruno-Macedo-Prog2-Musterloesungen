#include "cBruch.h"

#include <iostream>
using namespace std;

cBruch::cBruch(int zaehler_in, int nenner_in)
{
	zaehler = zaehler_in;

	if (nenner_in == 0) {
		nenner = 1;
	}
	else if (nenner_in < 0) {
		nenner = nenner_in *-1;
		zaehler = zaehler_in * -1; //Um -1 erweitern, sodass Vorzeichen getauscht werden
	}
	else {
		nenner = nenner_in;
	}
}

void cBruch::ausgabe() {
	cout << zaehler << "/" << nenner << " (" << (double)zaehler / nenner << ")" << endl;
}

double cBruch::ggT(int x, int y) {
	if (y == 0)
		return x;
	else return ggT(y, x % y);
}

void cBruch::kuerzen() {
	int temp = ggT(zaehler, nenner);
	zaehler = zaehler / temp;
	nenner = nenner / temp;
}

double cBruch::getGleitkomma() {
	double gleitKomma = (double)zaehler / nenner;
	return gleitKomma;
}