#include "cKompRat.h"

#include <iostream>
using namespace std;

cKompRat::cKompRat(cBruch real_in, cBruch imag_in) : real(real_in), imag(imag_in) //Man kann ueber die Konstruktorenkaskade auch so Werte befuellen
{

}

void cKompRat::ausgabe() {
	cout << "Realer Wert: "; real.ausgabe(); 
	cout << "Imaginaerer Wert: "; imag.ausgabe();
}

