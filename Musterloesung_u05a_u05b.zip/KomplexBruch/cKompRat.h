#pragma once
#include "cBruch.h"

class cKompRat
{
private:
	cBruch real;
	cBruch imag;
public:
	cKompRat(cBruch = { 0,0 }, cBruch = { 0,0 }); //Nenner mit 0 wird im cBruch Konstruktor abgefangen
	void ausgabe();

	//Freundfunktionen
	friend int kompRatVergleich(cKompRat, cKompRat);
	friend cKompRat add(cKompRat, cKompRat);
	friend cKompRat subt(cKompRat, cKompRat);
};
