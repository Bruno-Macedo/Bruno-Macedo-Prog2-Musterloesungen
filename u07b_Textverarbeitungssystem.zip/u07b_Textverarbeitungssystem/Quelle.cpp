/*
Author: Andrej Alpatov
Datum: 17.05.2022
Aufgabe: u07b In a word processing system, texts consisting of several lines are to be processed (copied). 
         The lines should be stored in an array of variables of the type string.
         The line contents are read from a sequential file.
Exercise content: Class with array of objects as attribute, references, copy constructor
*/
#include "cText.h"
#include "global.h" //for namespace tpr


int main() {

    cText rohText("Rohtext", tpr::ARRAY_SIZE, "Text_for_processing.txt");
    rohText.ausgabe();
    cText gedicht = rohText;
    gedicht.aendereBezeichnung("Gedicht");
    gedicht.ausgabe();
    gedicht.ersetzeZeile(tpr::STRING_NUMBER_TO_REPLACE, "als fuenftes ists mir einerlei");
    gedicht.ausgabe();

    return 0;
}
