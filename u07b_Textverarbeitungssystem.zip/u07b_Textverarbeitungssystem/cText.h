#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "global.h"
using namespace std;

class cText
{
private:
	string textbezeichnung;
	int anzahl_zeilen_des_texts;
	string *zeilen;

public:
	cText(const string &textbezeichnung, int zeilenanzahl, const string &dateinamen);
	cText(const cText& text_in);
	~cText();

	void ausgabe();
	void ersetzeZeile(int num, string neuText);
	void aendereBezeichnung(string neuBez);
};
