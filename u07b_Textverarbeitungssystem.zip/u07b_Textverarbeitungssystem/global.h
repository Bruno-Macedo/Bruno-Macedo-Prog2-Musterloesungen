#pragma once

#ifndef MY_GLOBALS_H
#define MY_GLOBALS_H

//name space for text processing
namespace tpr {
	const int ARRAY_SIZE = 8;
	const int STRING_NUMBER_TO_REPLACE = 5;
}

#endif
