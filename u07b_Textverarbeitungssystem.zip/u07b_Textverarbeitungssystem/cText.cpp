#include "cText.h"

cText::cText(const string &textbezeichnung, int zeilenanzahl, const string &dateiname)
{
	this->textbezeichnung = textbezeichnung;
	anzahl_zeilen_des_texts = zeilenanzahl;

	//if the memory allocation isn't possible
	if (!(zeilen = new string[tpr::ARRAY_SIZE])) {
		return;
	}

	//Create and open object for file reading
	ifstream file_object;
	file_object.open(dateiname);

	if (file_object.is_open()) {
		size_t line_number = 0;
		string temp_string;

		//copy all lines from text in file in a string array
		while (getline(file_object, temp_string) && line_number < tpr::ARRAY_SIZE)
		{
			zeilen[line_number] = temp_string;
			line_number++;
		}

		//close file object
		file_object.close();
	}
	else
	{
		//Error message if it wasn't possible to open the file
		cout << "Error: " << errno << endl;
		exit(errno);
	}

}

cText::cText(const cText& text_in)
{
	textbezeichnung = text_in.textbezeichnung;
	anzahl_zeilen_des_texts = text_in.anzahl_zeilen_des_texts;

	//if the memory allocation isn't possible
	if (!(zeilen = new string[tpr::ARRAY_SIZE])) {
		return;
	}

	//copy all string array elements from input array into class member array
	copy(text_in.zeilen, text_in.zeilen + anzahl_zeilen_des_texts, zeilen);

	//The second way for implementation
	//for (int i = 0; i < tpr::ARRAY_SIZE; i++) {
	//	zeilen[i] = text_in.zeilen[i];
	//}
}

cText::~cText()
{
	delete[]zeilen;
}

//Output in console the title of the text and the text as well
void cText::ausgabe()
{
	cout << "*****************************************" << endl;
	cout << "Textbezeichnung: " << textbezeichnung << endl << endl;
	for (int i = 0; i < anzahl_zeilen_des_texts; i++) {
		if (zeilen[i].size()) {
			cout << zeilen[i] << endl;
		}
	}
	cout << "*****************************************" << endl;
}

//replace one string in the text with the new one
//the number of string and the text to be written are input parameters
void cText::ersetzeZeile(int num, string neuText)

{
	//If the line number exists
	if (num < tpr::ARRAY_SIZE && num >= 0){
		zeilen[num] = neuText;
	}
	//if it doesn't exist
	else {
		cout << "Zeilennummer ist ungueltig" << endl;
	}

}

//changes the title of the text with new string as an input parameter
void cText::aendereBezeichnung(string neuBez)
{
	textbezeichnung = neuBez;
}
